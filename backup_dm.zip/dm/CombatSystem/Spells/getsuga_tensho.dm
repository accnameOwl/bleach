obj/spell/getsuga_tensho
	name = "Getsuga Tensho"

	icon = 'getsugatensho.dmi'
	bound_y = 1
	bound_x = 1
	step_size = 15
	step_delay = 0.25

	duration = SPELL_TIMEOUT_GETSUGATENSHO
	damage_type = MAGIC_TYPE

	New(mob/caster, time=world.time)
		.=..()
		dir = caster.dir
		