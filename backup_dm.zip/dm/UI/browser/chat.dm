mob/player
	verb
		OpenInputBrowser()
			var/html = {"
				<html>
					<head><title>Send text to BYOND</title></head>
					<body style='
						background:#111;
						color:#fff;
						display:flex;
						flex-direction:column;
						align-items:center;
						justify-content:center;
						height:100vh;'
						>
						<h2>Send text example</h2>
						<input type='text' id='myInput' placeholder='Type something...' style='padding:10px; margin-bottom:10px;'>
						<button onclick='sendInput()' style='padding:10px 20px; font-size:16px;'>Send</button>

						<script>
							function sendInput() {
								var text = document.getElementById('myInput').value;
								if(text.trim() == '') {
									alert('please type something first.');
									return;
								}
								window.location = \"byond://winset?id=;command=RecieveText \" + enconeURIComponent(text);
							}
						</script>
					</body>
				</html>
			"}

			src << browse(html, "window=inputbrowser;size=400x300;titlebar=1")
		ReceiveText(txt as text)
			src << "You sent: [txt]"