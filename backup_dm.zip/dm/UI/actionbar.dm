mob/player
	proc
		ShowActionBar()

			if(!src || !src.client)
				return
			//start building the actionbar

			/* START */
			var/html = {"
			<html>
				<head>
					<title></title>
					<body style=;>"}
			/* START */



			/* END */
			html += "</body></html>"
			/* END */