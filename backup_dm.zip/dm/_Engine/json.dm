

var/list
	json_data_monsters = json_decode(file2text('./json/monsters.json'))
	json_data_player = json_decode(file2text('./json/player.json'))
	json_data_npc = json_decode(file2text('./json/npc.json'))


atom
	var
		// name of object in json file
		json_id = ""




//Testing
proc/test_monster_config()
	if(!json_data_monsters)
		return list("monsters.json failed to parse"=null)
	
	var/list
		result = list()
		all_type_ids = list()
		unmatched_path_id_map = list()
	for(var/mob/monster/path as anything in (typesof(/mob/monster)-/mob/monster))
		var/json_id = initial(path.json_id)
		if(!json_data_monsters[json_id])
			unmatched_path_id_map[path] = json_id
		all_type_ids += json_id
	if(length(unmatched_path_id_map))
		result["unmatched types"] = unmatched_path_id_map
	
	var/list/unmatched_json_ids = list()
	for(var/json_id in json_data_monsters)
		if(!(json_id in all_type_ids))
			unmatched_json_ids += json_id
	if(length(unmatched_json_ids))
		result["unmatched json"] = unmatched_json_ids
	
	if(length(result))
		return result

mob/verb/test_monster()
	set category = "Test"
	set name = "JSON test"
	var/list/problems = test_monster_config()
	for(var/reason in problems)
		world << "[reason]: [json_encode(problems[reason])]"