mob
	player
		var
			tmp/AFK = 0

	monster
		icon = 'monsters.dmi'

		verb
			Bala()
				//small, weak, no traces
			Cero()
				//Normal Cero, leaving traces
			GranReyCero()
				//3xCero, leaving traces
			Sonido()
				//Step behind target
		New()
			..()
			var/list/decoded_data = global.json_data_monsters[json_id]
			name			= decoded_data["name"]
			level 			= decoded_data["level"]
			health_max 		= decoded_data["health"]
			reiatsu_max 	= decoded_data["reiatsu"]
			health_current 	= health_max
			reiatsu_current = reiatsu_max
			attack 			= decoded_data["attack"]
			defence 		= decoded_data["defence"]
			reiatsu_power 	= decoded_data["reiatsu-power"]
			reward_experience 		= decoded_data["reward_experience"]
			reward_attack 			= decoded_data["reward_attack"]
			reward_reiatsu_power	= decoded_data["reward_reiatsu_power"]
			reward_defence 			= decoded_data["reward_defence"]
			reward_health 			= decoded_data["reward_health"]
			reward_reiatsu 			= decoded_data["reward_reiatsu"]
			//AI stuff
			home_loc = loc
			respawn_loc = loc
			RestingState()
	NPC
		icon = 'npcs.dmi'

		New()
			..()
			var/list/decoded_data = global.json_data_npc[json_id]
			name = "{NPC}[decoded_data["name"]]"
			level = decoded_data["level"]