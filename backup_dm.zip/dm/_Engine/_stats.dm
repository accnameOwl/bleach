
mob
	var
		health_current = 0
		health_max = 0
		reiatsu_current = 0
		reiatsu_max = 0
		attack = 0
		defence = 0
		reiatsu_power = 0
		attack_buff_multipl = 1
		reishi_buff_multipl = 1
		hierro_buff_multipl = 1

		tmp/last_time_trained = -1#INF // world.time

		//Special attributes. (They don't require to be /datum/stat types)
		//dodge:	Max 25% -> 1sp=.5%
		dodge = 0
		//mitigation: max 40% -> 1sp=.5%
		mitigation = 0
		//regeneration: max 10% -> 1sp=.5%
		regeneration = 0

