trigger
	parent_type = /obj

	#ifdef __TEST__
	icon = 'trigger.dmi'
	#endif

	var/mob/anchored_to

	New(mob/anchor)
		anchored_to = anchor

	Crossed(mob/m)
		if(!ismob(m)) return
		if(m.godmode) return
		anchored_to.Trigger(m)

	ChangeBounds(x_offset = 0, y_offset = 0, extra_width = 0, extra_height = 0)
		pixel_x -= x_offset
		pixel_y -= y_offset
		bound_width = extra_width * world.icon_size
		bound_height = extra_height * world.icon_size

		step_x = (bound_width / 2)*-1
		step_y = (bound_height / 2)*-1

	proc/Scale(_x, _y)
		transform = new/matrix().Scale(_x+1,_y+1)

	proc/SetStep(mob/m)
		step_x = ((bound_width/2)-m.step_x)*-1
		step_y = ((bound_height/2)-m.step_y)*-1

mob/proc/Trigger()

mob/monster
	step_size = MONSTER_STEP_SIZE
	var/mob/target = null
	var/trigger/ai_trigger
	var/tmp/turf/home_loc
	var/aggro_dist=4
	var/attack_reach = 22 //pixels
	var/chase_speed = 1 //increased pixels to move

	var/last_attack_timestamp

	OnDeath(mob/killer)
		..(killer)
		target = null
		if(ai_trigger && ai_trigger.loc)
			ai_trigger.loc = null
	Trigger(mob/m)
		if(m.client)
			TargetState(m)

	Respawn()
		var/mob/monster/n = src
		if(!n)
			return

		var/_loc = respawn_loc
		var/_delay = respawn_time

		if(!_delay)
			n.combat_flag.dead = 1
			n.loc = null
			return
		n.combat_flag.dead = 1
		n.loc = null
		spawn(_delay)
			n.health_current = n.health_max
			n.combat_flag.dead = 0
			n.loc = _loc
			n.RestingState()

	proc

		RestingState()
			if(!ai_trigger)
				ai_trigger = new/trigger(src)
				ai_trigger.Scale(aggro_dist, aggro_dist)
				ai_trigger.ChangeBounds((aggro_dist * world.icon_size/2)*-1, (aggro_dist * world.icon_size / 2)*-1, aggro_dist, aggro_dist)
			ai_trigger.loc = src.loc
			step_rand_loop()

		TargetState(mob/new_target)
			if(!target)
				target = new_target
				ai_trigger.loc = null
				ai_trigger = null
				ChaseState()

		ChaseState()
			if(target)
				combat_flag.in_combat = TRUE
				walk(src, 0)

				var/_dist 	= get_dist(src, target)
				var/_dir	= get_dir(src, target)

				#define chase_step_size step_size+chase_speed

				while(_dist <= aggro_dist && target)

					_dist = get_dist(src, target)
					_dir = get_dir(src, target)

					if(_dist <= 1)
						dir = _dir
						var/_bounds_dist = bounds_dist(src, target)
						if(_bounds_dist > attack_reach)
							. = step(src, _dir, chase_step_size)
							if(!.)
								step_rand(src,chase_step_size)
						else
							if(!last_attack_timestamp)
								last_attack_timestamp = world.time
							if(world.time > last_attack_timestamp)
								Attack()
								last_attack_timestamp = world.time + SECOND(1)
					else
						. = step(src, _dir, chase_step_size)
						if(!.)
							step_rand(src, chase_step_size)

					if(target.combat_flag.dead)
						src.target = null
					if(src.combat_flag.dead)
						break

					sleep(10/world.fps)

				#undef chase_step_size

				target = null
				if(combat_flag.dead)
					return
			. = ResetState()

		ResetState()

			var/_dist = get_dist(src, home_loc)
			var/_dir = get_dir(src, home_loc)

			while(_dist > 0)
				. = step(src, _dir)

				_dist = get_dist(src, home_loc)
				_dir = get_dir(src, home_loc)
				sleep(world.tick_lag * chase_speed)
			combat_flag.in_combat = FALSE
			. = RestingState()



		step_rand_loop()
			while(src)
				if(combat_flag.in_combat)
					break
				if(combat_flag.dead)
					break
				var/_locToWalk
				dir = pick( NORTH, SOUTH, EAST, WEST)
				switch(dir)
					if(NORTH)
						_locToWalk = locate(x,y+2,z)
					if(SOUTH)
						_locToWalk = locate(x,y-2,z)
					if(EAST)
						_locToWalk = locate(x+2,y,z)
					if(WEST)
						_locToWalk = locate(x-2,y,z)
				walk_towards(src, _locToWalk,2,step_size)
				if(ai_trigger)
					ai_trigger.loc = loc
				sleep(rand(50,110))
