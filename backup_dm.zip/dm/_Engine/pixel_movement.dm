atom/movable
	step_size = 6
	var
		cached_step_size = 6
		step_delay=0.25
		tmp
			last_step = -1#INF
			next_step = -1#INF

atom/movable
	proc
		Step(dir, delay=step_delay)
			if(next_step - world.time >= world.tick_lag/10)
				return 0
			else
				if(step(src, dir))
					last_step = world.time
					next_step = last_step + step_delay
					return 1
				else
					return 0
		ChangeBounds(x, y, width, height)
			bound_x = x
			bound_y = y
			bound_width = width
			bound_height = height

		CrossedUncrossedBetweenBounds(old_overlap, new_overlap)
			if(old_overlap ~= new_overlap)
				for(var/atom/atom as anything in (old_overlap - new_overlap))
					atom.Uncrossed(src)
				for(var/atom/atom as anything in (new_overlap - old_overlap))
					atom.Crossed(src)

mob
	var
		block_steps = 0
		
	Step(dir, delay=step_delay)
		if(block_steps)
			return 0
		if(next_step - world.time >= world.tick_lag/10)
			return 0
		if(step(src, dir))
			last_step = world.time
			next_step = last_step + step_delay
			return 1
		else
			return 0

obj/step_size = OBJ_STEP_SIZE
mob/step_size = MOB_STEP_SIZE
mob/monster/step_size = MONSTER_STEP_SIZE
	

