var/list/OnlinePlayers = list()

mob
	player
		Login()
		//	var/loaded = src.load()
		//	if(!loaded)
			NewPlayerCharacter()

		//	if(is_banned(src))
		//		src << Bold(Red("You are banned!"))

			OnlinePlayers += src
			HudUpdate()
			//HTML_BrowseLogin()

			// ChatBrowser interface element
			// See /HTML/ChatBrowser.dm
			winshow(src,"mainwindow.childChat", 1) // you turn chat on whenever you want or hide it with 0
			AddWorldMessage("Everyone can see this msg")
			AddChatMessage("only this player can see this msg")
			AddGameLog("This is game log")
			OpenChatBrowser()

		Logout()
			src.save()
			OnlinePlayers.Remove(src.key)
			..()

		proc
			NewPlayerCharacter()
				icon = 'base.dmi'

				loc = locate(NEW_PLAYER_LOC)
				var/data = json_data_player
				health_current = data["health"]
				health_max = data["health"]
				reiatsu_current = data["reiatsu"]
				reiatsu_max = data["reiatsu"]
				attack = data["attack"]
				defence = data["defence"]
				reiatsu_power = data["reiatsu_power"]