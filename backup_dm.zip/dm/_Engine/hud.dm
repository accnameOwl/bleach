// prototype
obj/hud/button
	icon = 'hud_buttons.dmi'
	layer=FLOAT_LAYER
	plane=FLOAT_PLANE

	var
		obj/hud/button/background/background
		obj/hud/button/foreground/foreground
		obj/hud/button/foreground/masque

	proc/Build()


//functionality
obj/hud/button
	New(_icon_state=icon_state, _dir=dir)
		src.icon_state = _icon_state
		src.dir=_dir
		Build()
		vis_contents.Add(background,foreground,masque)
		..()

	Del()
		vis_contents.Remove(background,foreground,masque)
		..()

//elements
obj/hud/button

	background
		icon_state="bg"
	foreground
	masque
		icon_state="masque"

	Who
		screen_loc = "LEFT+1,TOP"
		Build()
			background = 	new/obj/hud/button/background("bg",SOUTHWEST)
			foreground = 	new/obj/hud/button/foreground("who")
			masque 	=	 	new/obj/hud/button/masque()
		//Click()
	Ooc
		screen_loc = "LEFT+2,TOP"
		Build()
			background = 	new/obj/hud/button/background("bg", SOUTH)
			foreground = 	new/obj/hud/button/foreground("ooc")
			masque 	= 		new/obj/hud/button/masque()
	Say
		screen_loc = "LEFT+3,TOP"
		Build()
			background = new/obj/hud/button/background("bg", SOUTH)
			foreground = new/obj/hud/button/foreground("say")
			masque =	 new/obj/hud/button/masque()
	Whisper
		screen_loc = "LEFT+2,TOP"
		Build()
			background = new/obj/hud/button/background("bg", SOUTH)
			foreground = new/obj/hud/button/foreground("whisper")
			masque =	 new/obj/hud/button/masque()
	Rest
		screen_loc = "LEFT+3,TOP"
		Build()
			background = new/obj/hud/button/background("bg", SOUTH)
			foreground = new/obj/hud/button/foreground("rest")
			masque =	 new/obj/hud/button/masque()
	Save
		screen_loc = "LEFT+4,TOP"
		Build()
			background = new/obj/hud/button/background("bg", SOUTH)
			foreground = new/obj/hud/button/foreground("save")
			masque =	 new/obj/hud/button/masque()
	Help
		screen_loc = "LEFT+5,TOP"
		Build()
			background = 	new/obj/hud/button/background("bg",SOUTHEAST)
			foreground = 	new/obj/hud/button/foreground("help")
			masque = 		new/obj/hud/button/masque()
	Character
		screen_loc = "RIGHT-4,BOTTOM"
		Build()
			background = 	new/obj/hud/button/background("bg",NORTHWEST)
			foreground = 	new/obj/hud/button/foreground("stats")
			masque = 		new/obj/hud/button/masque()
	Skillbook
		screen_loc = "RIGHT-3,BOTTOM"
		Build()
			background = 	new/obj/hud/button/background("bg",NORTH)
			foreground = 	new/obj/hud/button/foreground("skillbook")
			masque = 		new/obj/hud/button/masque()
	Inventory
		screen_loc = "RIGHT-2,BOTTOM"
		Build()
			background = 	new/obj/hud/button/background("bg",NORTH)
			foreground = 	new/obj/hud/button/foreground("inventory")
			masque = 		new/obj/hud/button/masque()
	Options
		screen_loc = "RIGHT-1,BOTTOM"
		Build()
			background = 	new/obj/hud/button/background("bg",NORTHEAST)
			foreground = 	new/obj/hud/button/foreground("options")
			masque = 		new/obj/hud/button/masque()

	Shikai
	Bankai
	//Arrancar Ressurection
	Ressurection
	//Espada Segunda
	Segunda
	//espada primera
	Primera
	//Quincy bow
	Bow
	//Quincy glove
	Glove
	//Quincy blut
	Blutvein

// interractive objects for client.screen
mob/player
	var
		obj/hud/button/Who/ui_elem_who
		obj/hud/button/Whisper/ui_elem_whisper
		obj/hud/button/Rest/ui_elem_rest
		obj/hud/button/Ooc/ui_elem_ooc
		obj/hud/button/Say/ui_elem_say
		obj/hud/button/Save/ui_elem_save
		obj/hud/button/Help/ui_elem_help
		obj/hud/button/Character/ui_elem_character
		obj/hud/button/Skillbook/ui_elem_skillbook
		obj/hud/button/Inventory/ui_elem_inventory
		obj/hud/button/Options/ui_elem_options
	proc
		HudUpdate()
			//remove existing elements
		//	client.screen.Remove(ui_elem_who, ui_elem_ooc,ui_elem_say,ui_elem_whisper,ui_elem_save,ui_elem_help)
			//create new elements
			ui_elem_who = new/obj/hud/button/Who()
			ui_elem_whisper = new/obj/hud/button/Whisper()
			ui_elem_rest = new/obj/hud/button/Rest()
			ui_elem_save = new/obj/hud/button/Save()
			ui_elem_help = new/obj/hud/button/Help()
			ui_elem_character = new/obj/hud/button/Character()
			ui_elem_skillbook = new/obj/hud/button/Skillbook()
			ui_elem_options = new/obj/hud/button/Options()
			ui_elem_inventory = new/obj/hud/button/Inventory()
			//add them to screen
			client.screen.Add(
				ui_elem_who,
				ui_elem_whisper,
				ui_elem_rest,
				ui_elem_save,
				ui_elem_help,
				ui_elem_character,
				ui_elem_skillbook,
				ui_elem_inventory,
				ui_elem_options
			)