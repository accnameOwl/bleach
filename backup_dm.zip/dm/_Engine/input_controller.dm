client
	var/block_move = 0
	var/block_input = 0
	var/list/keybind = list("1" = "Attack", "space" = "Train")
	var/list/move_buffer = list("W"=0,"S"=0,"A"=0,"D"=0)

	proc
		CallInputAction(key)
			if(key in keybind)
				var/cmd = keybind[key] || 0
				if(cmd)
					call(src.mob, cmd)()

		MovementInput() //called on mob.Tick()
			set waitfor = 0
			if(block_move) 
				return
			var/move_dir = (move_buffer["W"]*1) + (move_buffer["S"]*2) + (move_buffer["D"]*4) + (move_buffer["A"]*8)
			if(move_dir==3 || move_dir==12)
				move_dir=0
			mob.Step(move_dir, mob.step_size)
		//	sleep(10/world.fps)


	verb
		KeyDown(key as text)
			set hidden = 1
			set instant = 1
			if(block_input)
				return
			if(key in move_buffer)
				move_buffer[key]=1
			else
				CallInputAction(key)
			
		KeyUp(key as text)
			set hidden = 1
			set instant = 1
			if(block_input)
				return
			if(key in move_buffer)
				move_buffer[key]=0
		