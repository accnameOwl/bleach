obj/spell
	var
		uid = "" // casters key
		mob/caster
		duration = -1#INF
		start_time = 0
		active = 0
		
		damage = 0
		damage_type = ""
		
	proc
		Walk()
			set waitfor = 0
			active = 1
			while(src && active)
				// check duration
				if( (start_time + duration) < world.time)
					Expire()
				Step(dir, step_size)
				sleep(10/world.fps)
		
		Expire(time=world.time)
			active = 0
			loc = null
		
		OnHit(mob/caster, mob/bumped, time=world.time)
			//override proc
			//called on Bump()
		
		Damage(mob/caster, mob/target)
			//override damage proc
			//returns how much damage has been dealt.
			return 0
		

	Step(dir, delay = step_delay)
		//if next step not ready
		if(next_step - world.time >= world.tick_lag/10)
			return 0
		
		//if expired
		if(world.time > (start_time + duration))
			Expire()
		
		// movement
		if(step(src, dir))
			last_step = world.time
			next_step = last_step + delay
			return 1
		else
			return 0
	
	Bump(mob/m)
		..(m)
		if(caster != m)
			OnHit(caster, m, world.time)

	New(loc, mob/caster, time=world.time)
		src.uid = caster.key
		src.caster = caster
		src.dir = caster.dir
		src.start_time = time
		Damage(caster,time)
		..(loc)

	
mob
	var
		spell_mastery = list()
		spell_cd = list()
	proc
		// returns true or false
		CanCast(cost)
			return src.reiatsu_current >= cost 
		
		UseReiatsu(cost)
			if(cost < 0)
				cost = 0
			src.reiatsu_current -= cost
		
		