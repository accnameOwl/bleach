/*

	OBJ HELPERS

*/

var
	existing_spells[]


obj
	proc
		StepOffset(x_offset, y_offset)
			step_x = x_offset
			step_y = y_offset

