#define INDIVIDUAL_LEVELUP_BONUS
mob
	var/level = 1

	player
		var
			exp = 0
			req_exp = 100
			fatigue = 0
			total_exp = 0

		proc
			GiveExperience(value)
				exp += value
				total_exp += round(value)
				spawn CheckRaceRewards()
				while(exp >= req_exp) //gained a level
					++level

					#ifdef INDIVIDUAL_LEVELUP_BONUS
					health_current += LEVELUP_HEALTH_BONUS
					reiatsu_current += LEVELUP_REIATSU_BONUS
					health_max+= LEVELUP_HEALTH_BONUS
					reiatsu_max += LEVELUP_REIATSU_BONUS
					attack += LEVELUP_ATTACK_BONUS
					reiatsu_power += LEVELUP_REISHI_BONUS
					defence += LEVELUP_HIERRO_BONUS
					#endif

					src << Bold(Gold("Leveled up to ") + Silver("[level]") + Gold("!"))

					exp -= req_exp

					if(exp < 0)
						exp = 0
					req_exp += round(req_exp/20) ? round(req_exp/20) : 1 // if 0, then 1 instead


	monster
		var
			reward_experience = 0
			reward_attack = 0
			reward_reiatsu_power = 0
			reward_defence = 0
			reward_health = 0
			reward_reiatsu = 0

		proc
			Reward(mob/player/killer)
				killer.GiveExperience(reward_experience)
				killer.attack += reward_attack
				killer.reiatsu_power += reward_reiatsu_power
				killer.defence += reward_defence
				killer.health_current += reward_health
				killer.health_max += reward_health
				killer.reiatsu_current += reward_reiatsu
				killer.reiatsu_max += reward_reiatsu