client/Stat()
	var
		mob/player/p = mob
	stat("Name: ","[p.name]")
	stat("Race: ", p.race)
	if(mob.race == "Shinigami")
		stat("Division: Squad [p.squad_division]")
	stat("__________")
	stat("Level: ",p.level)
	stat("Exp: ", "[p.exp] / [p.req_exp]")
	stat("")
	stat("Health: ", "[p.health_current] / [p.health_max]")
	stat("Reiatsu: ", "[p.reiatsu_current] / [p.reiatsu_max]")
	stat("")
	stat("Attack: ", p.attack)
	stat("Reishi: ", p.reiatsu_power)
	stat("Hierro: ", p.defence)
	stat("")
	stat("Fatigue: ", round(p.fatigue))

	#if defined(SYS_LEVELING_CLIENT_STATPANEL_SHOW_NEW)
	stat("")
	stat("Extra:")
	stat("Dodge: ", "[round(p.dodge)]%")
	stat("Mitigation: ", "[round(p.mitigation)]%")
	stat("Regeneration: ", "[round(p.regeneration)]%")

	#endif

	statpanel("Inventory", p.contents)