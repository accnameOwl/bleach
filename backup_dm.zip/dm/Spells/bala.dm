obj/spell
	bala
		name = "Bala"
		icon = 'cero.dmi'
		icon_state = "bala"
		duration = SPELL_TIMEOUT_BALA
		step_size = SPELL_STEPSIZE_BALA
		step_size = 8
		damage_type = DARKMAGIC_TYPE

		Damage(mob/caster, time=world.time)
			src.damage = caster.reiatsu_power * SPELL_MULTIPL_CERO

mob/spell/verb
	// Bala
	bala()
		set name = "Bala"
		set category = "Attacks"

		if(!CanCast(SPELL_COST_BALA))
			src << Bold(Red("Insufficient mana to cast Bala!"))
			return 0

		//1: Charge cero
		UseReiatsu(SPELL_COST_BALA)
		var/obj/spell/bala/bala = new/obj/spell/bala(src.loc, src, world.time)
		bala.Walk()

