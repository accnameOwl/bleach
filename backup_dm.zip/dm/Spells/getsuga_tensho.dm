mob/spell/verb
	getsuga_tensho()
		set name = "Getsuga Tensho"
		set category = "Attacks"

		var/obj/spell/getsuga_tensho/o = new/obj/spell/getsuga_tensho(src)
		o.Walk()


obj/spell
	getsuga_charge
		layer = AURA_LAYER
		duration = 3

	getsuga_tensho
		name = "Getsuga Tensho"

		icon = 'getsugatensho.dmi'
		bound_y = 1
		bound_x = 1
		step_size = 15
		step_delay = 0.25

		duration = SPELL_TIMEOUT_GETSUGATENSHO
		damage_type = MAGIC_TYPE 

		New(loc, mob/caster, time=world.time)
			. = ..(loc, caster, time)
			if(.)
				switch(dir)
					if(SOUTH)
						ChangeBounds(1,1,160,65)
						x-=2
					if(EAST)
						ChangeBounds(97,1,63,160)
						y-=2
					if(WEST)
						ChangeBounds(1,64,63,160)
						y-=2

		Damage(mob/caster, time=world.time)
			src.damage = (caster.attack * 0.5) + caster.reiatsu_power