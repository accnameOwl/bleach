
obj/spell	
	granreycero_trail
		icon = 'cero.dmi'
		left
			icon_state="grc_trail_left"
		center
			icon_state="grc_trail_center"
		right
			icon_state="grc_trail_right"

//Gran rey cero
	granreycero
		name = "Gran Rey Cero"
		step_size = SPELL_GRC_STEP_SIZE
		icon = 'cero.dmi'
		duration = SPELL_TIMEOUT_GRANREYCERO 
		density = 1
		damage_type = DARKMAGIC_TYPE
		
		left
			icon_state = "grc_left"

			Step(dir,delay=step_delay)
				var/prev_x = x
				var/prev_y = y
				. = ..(dir, delay)
				if(.)
					//if moved one tile
					if(prev_x != x || prev_y != y)
						var/obj/spell/granreycero_trail/left/trail = new/obj/spell/granreycero_trail/left(null, src.dir, src.loc, src.step_x, src.step_y)
						switch(dir)
							if(NORTH)
								trail.step_y = src.step_y-(TILE_HEIGHT/4)
							if(SOUTH)
								trail.step_y = src.step_y+(TILE_HEIGHT/4)
							if(EAST)
								trail.step_x = src.step_x-(TILE_WIDTH/4)
							if(WEST)
								trail.step_x = src.step_x+(TILE_WIDTH/4)

			center
				icon_state = "grc_center"

				Step(dir,delay=step_delay)
					var/prev_x = x
					var/prev_y = y
					//run ..Step()
					. = ..(dir, delay)
					if(.)
						//if moved one tile
						if(prev_x != x || prev_y != y)
							var/obj/spell/granreycero_trail/center/trail = new/obj/spell/granreycero_trail/center(null, src.dir, src.loc, src.step_x, src.step_y)
							switch(dir)
								if(NORTH)
									trail.step_y = src.step_y-(TILE_HEIGHT/4)
								if(SOUTH)
									trail.step_y = src.step_y+(TILE_HEIGHT/4)
								if(EAST)
									trail.step_x = src.step_x-(TILE_WIDTH/4)
								if(WEST)
									trail.step_x = src.step_x+(TILE_WIDTH/4)
			right
				icon_state = "grc_right"

				Step(dir,delay=step_delay)
					var/prev_x = x
					var/prev_y = y
					//run ..Step()
					. = ..(dir, delay)
					if(.)
						//if moved one tile
						if(prev_x != x || prev_y != y)
							var/obj/spell/granreycero_trail/right/trail = new/obj/spell/granreycero_trail/right(null, src.dir, src.loc, src.step_x, src.step_y)
							switch(dir)
								if(NORTH)
									trail.step_y = src.step_y-(TILE_HEIGHT/4)
								if(SOUTH)
									trail.step_y = src.step_y+(TILE_HEIGHT/4)
								if(EAST)
									trail.step_x = src.step_x-(TILE_WIDTH/4)
								if(WEST)
									trail.step_x = src.step_x+(TILE_WIDTH/4)
