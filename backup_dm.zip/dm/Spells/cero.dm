
obj/spell
	cero
		name = "Cero"
		icon = 'cero.dmi'
		icon_state = "cero"
		duration = SPELL_TIMEOUT_CERO
		step_size = SPELL_STEPSIZE_CERO

		var/trails[]

		Damage(mob/caster, mob/target)
			return  (caster.reiatsu_power * SPELL_MULTIPL_CERO) - (target.defence/2)

		Move()
			var/k = new/obj/spell/cerotrail(src.loc)
			trails.Add(k)
			k:dir = src.dir
			..()
		
		Expire(time=world.time)
			for(var/obj/spell/cerotrail/c in trails)
				c.Expire(time)
				trails = null
			..()

	cerotrail
		icon = 'cero.dmi'
		icon_state = "cero_trail"

mob/spell/verb
	cero()
		set name = "Cero"
		set category = "Attacks"
		//Check reiatsu
		if(!CanCast(SPELL_COST_CERO))
			src << Bold(Red("Insufficient mana to cast Cero"))
			return 0

		//1: Charge cero
		UseReiatsu(SPELL_COST_CERO)
			//charge speed depends on cero mastery

		//2: send cero
		var/obj/spell/cero/cero = new/obj/spell/cero(src.loc, src, world.time)
		cero.Walk()
