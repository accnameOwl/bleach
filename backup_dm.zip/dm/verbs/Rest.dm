mob/player/verb/Rest()
	var/last_tick = 0
	if(combat_flag.in_combat)
		src << Bold(Red("You cannot rest while in combat!"))
		return 0
	if(resting)
		src << Bold(White("You are already Resting..."))
		return 0
	resting = TRUE
	src.icon_state = "rest"
	src << Bold(White("You started to rest!"))
	while(resting)
		var
			hc = &health_current
			hm = &health_max
			rc = &reiatsu_current
			rm = &reiatsu_max
		if(world.time > last_tick+5)
			if(*hc < *hm)
				*hc += round(*hm/30)
			if(*hc > *hm)
				*hc= *hm

			if(*rc < *rm)
				*rc += round(*rm/30)
			if(*rc > *rm)
				*rc = *rm

			if(fatigue > 0)
				fatigue -= 0.666
			if(fatigue < 0)
				fatigue = 0

			if(*hc >= *hm && *rc >= *rm && fatigue <= 0)
				break
			last_tick = world.time
		sleep(10/world.fps)
	src.icon_state = ""
	resting = FALSE
	src << Bold(White("You finished resting!"))