
mob/player/verb/Who()
	for(var/mob/m in OnlinePlayers)
		src << Bold((Blue("[m.name] / [m.key] - [m.race] (") + Yellow("[m.level]") + Blue(")")))