mob/monster/
	// @Shinigami Hard
	Shinigami_Hard
		icon='shinigami.dmi'
		json_id = "shinigami_hard"

		aggro_dist=10
		attack_reach = 1
		chase_speed = 2
		respawn_time = 10
	// @Shinigami Medium
	Shinigami_Medium
		icon='shinigami.dmi'
		json_id = "shinigami_medium"

		aggro_dist=10
		attack_reach = 1
		chase_speed = 2
		respawn_time = 10
	// @Shinigami Easy
	Shinigami_Easy
		icon='shinigami.dmi'
		json_id = "shinigami_easy"

		aggro_dist=10
		attack_reach = 1
		chase_speed = 2
		respawn_time = 10
	// @Shinigami Leutenant
	Shinigami_leutenant
		icon='shinigami.dmi'
		json_id = "shinigami_leutenant"

		aggro_dist=10
		attack_reach = 1
		chase_speed = 2
		respawn_time = 10
	// @Shinigami Captain
	Shinigami_Captain
		icon='shinigami.dmi'
		json_id = "shinigami_captain"

		aggro_dist=10
		attack_reach = 1
		chase_speed = 2
		respawn_time = 10

	// @Zaraki
	Zaraki
		icon='zaraki_kenpachi.dmi'
		json_id = "zaraki"

		aggro_dist=10
		attack_reach = 1
		chase_speed = 2
		respawn_time = 10

		OnDeath(mob/killer)
			.=..(killer)
			if(.)
				Reward(killer)
	Quincy
		json_id="quincy"
	
	VastoLorde
		json_id="vasto_lorde"

	// @Byakuya
	Byakuya
		icon = 'byakuya_kuchiki.dmi'
		json_id = "byakuya"

		aggro_dist=10
		attack_reach = 1
		chase_speed = 4
		respawn_time = 10

		OnDeath(mob/killer)
			..()
			Reward(killer)

	// @Demihollow
	Demihollow
		icon_state = "demihollow"
		json_id = "demi_hollow"

		aggro_dist=10
		attack_reach = 1
		chase_speed = 4
		respawn_time = 60

	// @Hollow
	Hollow
		icon_state = "hollow"
		race = "Hollow"
		json_id = "hollow"

		aggro_dist=10
		attack_reach = 1
		chase_speed = 2
		respawn_time = 120

	// @Large Hollow
	LargeHollow
		icon = 'largehollow.dmi'
		race = "Hollow"
		json_id = "large_hollow"

		aggro_dist=10
		attack_reach = 1
		chase_speed = 2
		respawn_time = 10

		bounds = "32,1 to 64,32"

		step_rand_loop()
			while(src)
				if(combat_flag.in_combat)
					break
				if(combat_flag.dead)
					break
				var/_locToWalk
				dir = pick( NORTH, SOUTH, EAST, WEST)
				switch(dir)
					if(NORTH)
						_locToWalk = locate(x,y+2,z)
					if(SOUTH)
						_locToWalk = locate(x,y-2,z)
					if(EAST)
						_locToWalk = locate(x+2,y,z)
					if(WEST)
						_locToWalk = locate(x-2,y,z)
				walk_towards(src, _locToWalk,0,1)
				if(ai_trigger)
					ai_trigger.loc = loc
				sleep(rand(50,110))

	// @Menos Grande
	MenosGrande
		icon= 'menosgrande.dmi'
		json_id = "menos_grande"

		aggro_dist=10
		attack_reach = 1
		chase_speed = 2
		respawn_time = 60

		bounds = "1,1 to 32,32"

		step_rand_loop()
			while(src)
				if(combat_flag.in_combat)
					break
				if(combat_flag.dead)
					break
				var/_locToWalk
				dir = pick( NORTH, SOUTH, EAST, WEST)
				switch(dir)
					if(NORTH)
						_locToWalk = locate(x,y+2,z)
					if(SOUTH)
						_locToWalk = locate(x,y-2,z)
					if(EAST)
						_locToWalk = locate(x+2,y,z)
					if(WEST)
						_locToWalk = locate(x-2,y,z)
				walk_towards(src, _locToWalk,0,1)
				if(ai_trigger)
					ai_trigger.loc = loc
				sleep(rand(50,110))

	// @AttackArrancar
	AttackArrancar
		icon_state = "arrancarattack"

		json_id = "arrancar_atk"

		aggro_dist=10
		attack_reach = 1
		chase_speed = 3
		respawn_time = 600

	// @reiatsu_powerArrancar
	ReiatsuArrancar
		name = "Arrancar"
		icon_state = "arrancarreiatsu_power"

		json_id = "arrancar_rei"

		aggro_dist=10
		attack_reach = 1
		chase_speed = 3
		respawn_time = 600

		OnDeath(mob/killer)
			..(killer)
			Reward(killer)

	// @Grimjow
	Grimjow
		name = "Grimjow Jaggerjack"
		icon='grimjow_jaggarjack.dmi'

		json_id = "grimjow"

		aggro_dist=10
		attack_reach = 1
		chase_speed = 4
		respawn_time = 600


	// @Ulquiorra
	Ulquiorra
		name = "Ulquiorra Cifer"
		icon = 'ulquiorra_chifer.dmi'

		json_id = "ulquiorra"

		aggro_dist=10
		attack_reach = 1
		chase_speed = 4
		respawn_time = 10
